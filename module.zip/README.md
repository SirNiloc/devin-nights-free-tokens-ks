# devin-nights-free-tokens-ks
Module for Devin Night's Free KS Tokens.

The really awesome tokens were made by Devin Night.

Sources Site:
https://immortalnights.com/tokensite/

Token Usage:
https://immortalnights.com/tokens/token-usage-rights/
